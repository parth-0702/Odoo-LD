globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/bali-70OxdhPD.jpg": {
		"type": "image/jpeg",
		"etag": "\"1a190-1gyeoYs9vS82Fp6aM5XgiOF1hMY\"",
		"mtime": "2026-08-22T06:52:45.338Z",
		"size": 106896,
		"path": "../public/assets/bali-70OxdhPD.jpg"
	},
	"/assets/alps-BxUGqFM0.jpg": {
		"type": "image/jpeg",
		"etag": "\"1eabd-lXCk70ee11DC3A4a1TShDUEIXQY\"",
		"mtime": "2026-08-22T06:52:45.338Z",
		"size": 125629,
		"path": "../public/assets/alps-BxUGqFM0.jpg"
	},
	"/assets/button-Du6Z4RnB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8432-yghDnHgMpfAz9/wlELKwbuheA/k\"",
		"mtime": "2026-08-22T06:52:45.336Z",
		"size": 33842,
		"path": "../public/assets/button-Du6Z4RnB.js"
	},
	"/assets/dubai-Bab0gJAh.jpg": {
		"type": "image/jpeg",
		"etag": "\"13c9e-ZJDf0TouIiB3jMuDxkEjWSM8n0A\"",
		"mtime": "2026-08-22T06:52:45.339Z",
		"size": 81054,
		"path": "../public/assets/dubai-Bab0gJAh.jpg"
	},
	"/assets/globe-Beh0RjRp.jpg": {
		"type": "image/jpeg",
		"etag": "\"1cbda-6JeG56GX+JSGKToaEJcWiwZviLs\"",
		"mtime": "2026-08-22T06:52:45.339Z",
		"size": 117722,
		"path": "../public/assets/globe-Beh0RjRp.jpg"
	},
	"/assets/himalaya-oU-6zQQS.jpg": {
		"type": "image/jpeg",
		"etag": "\"335e5-N2PrulFMxoA/ufpD7Ixftc5YkHA\"",
		"mtime": "2026-08-22T06:52:45.340Z",
		"size": 210405,
		"path": "../public/assets/himalaya-oU-6zQQS.jpg"
	},
	"/assets/iceland-DmzUCyvf.jpg": {
		"type": "image/jpeg",
		"etag": "\"164cc-dKhRkTX+4gBMyZctj3DYvDT4yF0\"",
		"mtime": "2026-08-22T06:52:45.341Z",
		"size": 91340,
		"path": "../public/assets/iceland-DmzUCyvf.jpg"
	},
	"/assets/interlaken-XGf7Ep15.jpg": {
		"type": "image/jpeg",
		"etag": "\"14bdc-fkAQPSjT0yhWHfDnTOJQopRgrFA\"",
		"mtime": "2026-08-22T06:52:45.342Z",
		"size": 84956,
		"path": "../public/assets/interlaken-XGf7Ep15.jpg"
	},
	"/assets/kyoto-DAIwZ2xJ.jpg": {
		"type": "image/jpeg",
		"etag": "\"26e94-kTUwOQPN791KhgtHbkxFMrY65eA\"",
		"mtime": "2026-08-22T06:52:45.342Z",
		"size": 159380,
		"path": "../public/assets/kyoto-DAIwZ2xJ.jpg"
	},
	"/assets/hero-lcWRsf_Q.jpg": {
		"type": "image/jpeg",
		"etag": "\"33ab9-Q3Q4/zu6RLt/E2i7/VAGFkbBkGA\"",
		"mtime": "2026-08-22T06:52:45.340Z",
		"size": 211641,
		"path": "../public/assets/hero-lcWRsf_Q.jpg"
	},
	"/assets/label-XUtZZHJi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"687-kDeLiTvOaQ+nQiTNC5wOwUneTkY\"",
		"mtime": "2026-08-22T06:52:45.336Z",
		"size": 1671,
		"path": "../public/assets/label-XUtZZHJi.js"
	},
	"/assets/login-C2wKlJGd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b02-wQIJVgBzQlJIvOgxyW9ULlpajGo\"",
		"mtime": "2026-08-22T06:52:45.336Z",
		"size": 2818,
		"path": "../public/assets/login-C2wKlJGd.js"
	},
	"/assets/paris-C_GZoEBv.jpg": {
		"type": "image/jpeg",
		"etag": "\"1762a-0LMJeDIP2rQKuEuJm6dksfeJZNg\"",
		"mtime": "2026-08-22T06:52:45.343Z",
		"size": 95786,
		"path": "../public/assets/paris-C_GZoEBv.jpg"
	},
	"/assets/routes-C7lDySX6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"78f4-NZ4g/UIh7sRF1n0NO3/N1A8lk+g\"",
		"mtime": "2026-08-22T06:52:45.337Z",
		"size": 30964,
		"path": "../public/assets/routes-C7lDySX6.js"
	},
	"/assets/signup-DLsmJRg6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c74-2Qge47X/SEd+0+6Ac+OnJPRR16Q\"",
		"mtime": "2026-08-22T06:52:45.337Z",
		"size": 3188,
		"path": "../public/assets/signup-DLsmJRg6.js"
	},
	"/assets/patagonia-PxxxIHNt.jpg": {
		"type": "image/jpeg",
		"etag": "\"18f08-3lWbrO7UT1gjJhVM6rF4lK0PqCM\"",
		"mtime": "2026-08-22T06:52:45.343Z",
		"size": 102152,
		"path": "../public/assets/patagonia-PxxxIHNt.jpg"
	},
	"/assets/styles-DST7VioX.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"15d4d-tbhyX6CFM25LfOVR6WHjFwKSVRY\"",
		"mtime": "2026-08-22T06:52:45.344Z",
		"size": 89421,
		"path": "../public/assets/styles-DST7VioX.css"
	},
	"/assets/story--44YF01H.jpg": {
		"type": "image/jpeg",
		"etag": "\"185ac-lPCIcR37eWx5p3tNIHcDV6Sm8LM\"",
		"mtime": "2026-08-22T06:52:45.344Z",
		"size": 99756,
		"path": "../public/assets/story--44YF01H.jpg"
	},
	"/assets/zurich-BqxEdLBG.jpg": {
		"type": "image/jpeg",
		"etag": "\"1fb11-SfL7E+RkoY1Etc9t1h5IAHiYDSk\"",
		"mtime": "2026-08-22T06:52:45.345Z",
		"size": 129809,
		"path": "../public/assets/zurich-BqxEdLBG.jpg"
	},
	"/assets/tokyo-BYTzBaOy.jpg": {
		"type": "image/jpeg",
		"etag": "\"2b4c4-k1/3U8ExDFBNOnX12sKwstNqpoM\"",
		"mtime": "2026-08-22T06:52:45.345Z",
		"size": 177348,
		"path": "../public/assets/tokyo-BYTzBaOy.jpg"
	},
	"/assets/index-fe2TZUsu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8687c-nKsiNunBT+Skv791AoSCwWQIems\"",
		"mtime": "2026-08-22T06:52:45.336Z",
		"size": 551036,
		"path": "../public/assets/index-fe2TZUsu.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-08-22T06:14:01.054Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-08-22T06:14:01.028Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_erf_rQ = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_erf_rQ
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
