//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CImv6yIu.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "E:/PROJECTS/Odoo-travel/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/signup"
		],
		preloads: ["/assets/index-fe2TZUsu.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-fe2TZUsu.js"
		} }]
	},
	"/": {
		filePath: "E:/PROJECTS/Odoo-travel/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C7lDySX6.js", "/assets/button-Du6Z4RnB.js"]
	},
	"/login": {
		filePath: "E:/PROJECTS/Odoo-travel/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-C2wKlJGd.js",
			"/assets/button-Du6Z4RnB.js",
			"/assets/label-XUtZZHJi.js"
		]
	},
	"/signup": {
		filePath: "E:/PROJECTS/Odoo-travel/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-DLsmJRg6.js",
			"/assets/button-Du6Z4RnB.js",
			"/assets/label-XUtZZHJi.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
