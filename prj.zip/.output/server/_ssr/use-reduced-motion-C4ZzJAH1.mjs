import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-reduced-motion-C4ZzJAH1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* Returns true when the user has requested reduced motion via OS/browser settings.
* When true, all heavy animations (parallax, count-up, hero sequence) should
* be disabled or significantly simplified.
*/
function useReducedMotion() {
	const [reduced, setReduced] = (0, import_react.useState)(() => {
		if (typeof window === "undefined") return false;
		return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	});
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
		const handler = (e) => setReduced(e.matches);
		mq.addEventListener("change", handler);
		return () => mq.removeEventListener("change", handler);
	}, []);
	return reduced;
}
//#endregion
export { useReducedMotion as t };
