import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { c as useStore, i as cityById, n as activities, o as images, r as cities, s as seedTrips } from "./store-B2Wlh29_.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as MapPin, c as ArrowUpRight, i as Menu, l as ArrowRight, n as Quote, r as Plus, s as Clock, t as X } from "../_libs/lucide-react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as Logo, r as cn, t as Button } from "./button-BoE6ZHHJ.mjs";
import { n as gsapWithCSS, t as ScrollTrigger } from "../_libs/gsap.mjs";
import { t as useReducedMotion } from "./use-reduced-motion-C4ZzJAH1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-hl2FNqlY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var links = [
	{
		label: "Explore",
		to: "/explore/cities"
	},
	{
		label: "Destinations",
		to: "/explore/cities"
	},
	{
		label: "Experiences",
		to: "/explore/activities"
	},
	{
		label: "How It Works",
		to: "/",
		hash: "how-it-works"
	}
];
function SiteNav() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	const { isAuthed } = useStore();
	const navRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 24);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		const el = navRef.current;
		if (!el) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		el.style.opacity = "0";
		el.style.transform = "translateY(-12px)";
		const timer = setTimeout(() => {
			el.style.transition = "opacity 0.6s ease, transform 0.6s cubic-bezier(0.22,1,0.36,1)";
			el.style.opacity = "1";
			el.style.transform = "translateY(0)";
		}, 200);
		return () => clearTimeout(timer);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		ref: navRef,
		className: "fixed inset-x-0 top-0 z-50 px-3 pt-3 sm:px-6 sm:pt-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: cn("mx-auto flex max-w-6xl items-center justify-between rounded-full border border-border/70 bg-card/85 backdrop-blur-md transition-all duration-300", scrolled ? "px-4 py-2 shadow-soft sm:px-5" : "px-4 py-3 sm:px-6"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden items-center gap-7 md:flex",
					children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: link.to,
						hash: "hash" in link ? link.hash : void 0,
						className: "group relative text-sm text-muted-foreground transition-colors hover:text-foreground",
						children: [link.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -bottom-0.5 left-0 h-px w-0 bg-foreground/40 transition-all duration-300 group-hover:w-full" })]
					}, link.label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden items-center gap-2 md:flex",
					children: isAuthed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						className: "btn-tactile rounded-full px-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/dashboard",
							children: "Dashboard"
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "ghost",
						size: "sm",
						className: "btn-tactile rounded-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							children: "Login"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						className: "btn-tactile rounded-full px-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/signup",
							children: "Plan a Trip"
						})
					})] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Toggle menu",
					onClick: () => setOpen((v) => !v),
					className: "grid size-9 place-items-center rounded-full border border-border transition-colors hover:bg-secondary md:hidden",
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-4" })
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto mt-2 max-w-6xl rounded-3xl border border-border bg-card p-4 shadow-lift md:hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col",
				children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: link.to,
					hash: "hash" in link ? link.hash : void 0,
					onClick: () => setOpen(false),
					className: "border-b border-border/60 py-3 text-sm last:border-0",
					children: link.label
				}, link.label))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "outline",
					className: "rounded-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: isAuthed ? "/dashboard" : "/login",
						children: isAuthed ? "Dashboard" : "Login"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "rounded-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: isAuthed ? "/trips/create" : "/signup",
						children: "Plan a Trip"
					})
				})]
			})]
		})]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "border-t border-border bg-secondary/60",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5 py-14 sm:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm leading-relaxed text-muted-foreground",
							children: "GlobeTrotter is a planning studio for multi-city journeys — routes, days, activities and budgets in one place."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterCol, {
						title: "Plan",
						items: [
							{
								label: "Create a trip",
								to: "/trips/create"
							},
							{
								label: "My trips",
								to: "/trips"
							},
							{
								label: "Cities",
								to: "/explore/cities"
							},
							{
								label: "Experiences",
								to: "/explore/activities"
							}
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterCol, {
						title: "Account",
						items: [
							{
								label: "Dashboard",
								to: "/dashboard"
							},
							{
								label: "Profile",
								to: "/profile"
							},
							{
								label: "Login",
								to: "/login"
							},
							{
								label: "Sign up",
								to: "/signup"
							}
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterCol, {
						title: "Company",
						items: [{
							label: "Admin analytics",
							to: "/admin"
						}, {
							label: "Shared itinerary",
							to: "/share/european-summer-escape"
						}]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 flex flex-col gap-2 border-t border-border pt-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" GlobeTrotter. Plan the journey. Live the story."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Made for travellers who like knowing what the day costs." })]
			})]
		})
	});
}
function FooterCol({ title, items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "eyebrow",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-4 space-y-2.5",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: item.to,
			className: "text-sm text-muted-foreground transition-colors hover:text-foreground",
			children: item.label
		}) }, item.label))
	})] });
}
function DestinationCard({ city, className, ratio = "aspect-[4/5]", size = "md" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/explore/cities",
		search: { q: city.name },
		className: cn("group image-zoom card-lift relative block rounded-3xl", ratio, className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: city.image,
				alt: `${city.name}, ${city.country}`,
				loading: "lazy",
				className: "absolute inset-0 size-full rounded-3xl object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 rounded-3xl bg-gradient-to-t from-ink/75 via-ink/10 to-transparent transition-opacity duration-500 group-hover:opacity-90" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[0.68rem] uppercase tracking-[0.16em] text-white/70",
							children: city.country
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: cn("truncate font-display text-white transition-transform duration-500 group-hover:translate-y-[-2px]", size === "lg" ? "text-4xl" : "text-2xl"),
							children: city.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-white/75",
							children: [
								city.popularity,
								"% popularity · ",
								city.costIndex,
								" cost"
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-9 shrink-0 place-items-center rounded-full bg-card text-foreground transition-transform duration-300 group-hover:-translate-y-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })
				})]
			})
		]
	});
}
var badgeVariants = cva("inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
		secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
		destructive: "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
		outline: "text-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var inr = (value) => "₹" + Math.round(value).toLocaleString("en-IN");
var durationLabel = (mins) => mins >= 60 ? `${Math.floor(mins / 60)}h${mins % 60 ? ` ${mins % 60}m` : ""}` : `${mins}m`;
function ActivityCard({ activity, onAdd, actionLabel = "Add to Day" }) {
	const city = cityById(activity.cityId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "panel image-zoom card-lift flex flex-col overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative aspect-[16/9]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: activity.image,
				alt: activity.name,
				loading: "lazy",
				className: "absolute inset-0 size-full object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				className: "absolute left-3 top-3 rounded-full bg-card text-foreground hover:bg-card",
				children: activity.category
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-xl leading-tight",
					children: activity.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1.5 flex items-center gap-1.5 text-sm text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }),
						" ",
						city?.name,
						", ",
						city?.country
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 flex-1 text-sm leading-relaxed text-muted-foreground",
					children: activity.description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center justify-between border-t border-border pt-4 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5 text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }),
							" ",
							durationLabel(activity.durationMins)
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: activity.cost === 0 ? "Free" : inr(activity.cost)
					})]
				}),
				onAdd && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					className: "mt-4 w-full rounded-full",
					onClick: () => onAdd(activity),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
						" ",
						actionLabel
					]
				})
			]
		})]
	});
}
var featuredCities = cities.filter((c) => [
	"tokyo",
	"paris",
	"reykjavik",
	"bali",
	"swiss-alps",
	"dubai",
	"kyoto",
	"patagonia"
].includes(c.id));
var steps = [
	{
		n: "01",
		title: "Discover",
		body: "Search cities and experiences by region, cost index and the kind of day you want."
	},
	{
		n: "02",
		title: "Design",
		body: "Stack cities into a route, assign nights, then fill each day hour by hour."
	},
	{
		n: "03",
		title: "Balance",
		body: "Every activity carries a cost, so the budget updates as the plan changes."
	},
	{
		n: "04",
		title: "Share",
		body: "Publish a public itinerary friends can read — or copy into their own account."
	}
];
function animateCountUp(el, target, suffix, prefix, duration) {
	const start = { val: 0 };
	gsapWithCSS.to(start, {
		val: target,
		duration,
		ease: "power2.out",
		onUpdate() {
			el.textContent = prefix + (target >= 1e3 ? Math.round(start.val / 1e3) + "K" : Math.round(start.val).toString()) + suffix;
		},
		scrollTrigger: {
			trigger: el,
			start: "top 85%",
			once: true
		}
	});
}
function Landing() {
	const sampleTrip = seedTrips()[0];
	const reducedMotion = useReducedMotion();
	const heroRef = (0, import_react.useRef)(null);
	const eyebrowRef = (0, import_react.useRef)(null);
	const headlineLine1Ref = (0, import_react.useRef)(null);
	const headlineLine2Ref = (0, import_react.useRef)(null);
	const descRef = (0, import_react.useRef)(null);
	const ctaRef = (0, import_react.useRef)(null);
	const statsRef = (0, import_react.useRef)(null);
	const heroImageWrapRef = (0, import_react.useRef)(null);
	const heroImgRef = (0, import_react.useRef)(null);
	const floatLabelsRef = (0, import_react.useRef)(null);
	const destSectionRef = (0, import_react.useRef)(null);
	const destGridRef = (0, import_react.useRef)(null);
	const globeSectionRef = (0, import_react.useRef)(null);
	const globeImgRef = (0, import_react.useRef)(null);
	const globeFloatsRef = (0, import_react.useRef)(null);
	const statsCardsRef = (0, import_react.useRef)(null);
	const howWorksRef = (0, import_react.useRef)(null);
	const stepsRef = (0, import_react.useRef)(null);
	const featuredSectionRef = (0, import_react.useRef)(null);
	const featuredGridRef = (0, import_react.useRef)(null);
	const plannerSectionRef = (0, import_react.useRef)(null);
	const plannerTextRef = (0, import_react.useRef)(null);
	const plannerCardRef = (0, import_react.useRef)(null);
	const storiesSectionRef = (0, import_react.useRef)(null);
	const storiesImageRef = (0, import_react.useRef)(null);
	const storiesTextRef = (0, import_react.useRef)(null);
	const communitySectionRef = (0, import_react.useRef)(null);
	const communityCardsRef = (0, import_react.useRef)(null);
	const finalCtaRef = (0, import_react.useRef)(null);
	const stat300Ref = (0, import_react.useRef)(null);
	const stat12kRef = (0, import_react.useRef)(null);
	const stat100Ref = (0, import_react.useRef)(null);
	const stat22kRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (reducedMotion) return;
		const els = [
			eyebrowRef.current,
			headlineLine1Ref.current,
			headlineLine2Ref.current,
			descRef.current,
			ctaRef.current,
			statsRef.current
		].filter(Boolean);
		gsapWithCSS.set(els, {
			opacity: 0,
			y: 28
		});
		gsapWithCSS.set(heroImageWrapRef.current, {
			opacity: 0,
			clipPath: "inset(8% 8% 8% 8% round 2.5rem)"
		});
		gsapWithCSS.set(heroImgRef.current, { scale: 1.1 });
		if (floatLabelsRef.current) gsapWithCSS.set(floatLabelsRef.current.children, {
			opacity: 0,
			scale: .88,
			y: 10
		});
		const tl = gsapWithCSS.timeline({ delay: .1 });
		tl.to(eyebrowRef.current, {
			opacity: 1,
			y: 0,
			duration: .55
		}).to(headlineLine1Ref.current, {
			opacity: 1,
			y: 0,
			duration: .65,
			ease: "power4.out"
		}, "-=0.3").to(headlineLine2Ref.current, {
			opacity: 1,
			y: 0,
			duration: .65,
			ease: "power4.out"
		}, "-=0.4").to(descRef.current, {
			opacity: 1,
			y: 0,
			duration: .55
		}, "-=0.3").to(ctaRef.current, {
			opacity: 1,
			y: 0,
			duration: .5
		}, "-=0.25").to(statsRef.current, {
			opacity: 1,
			y: 0,
			duration: .5
		}, "-=0.25").to(heroImageWrapRef.current, {
			opacity: 1,
			clipPath: "inset(0% 0% 0% 0% round 2.5rem)",
			duration: 1,
			ease: "power3.inOut"
		}, .2).to(heroImgRef.current, {
			scale: 1,
			duration: 1.4,
			ease: "power2.out"
		}, .2).to(floatLabelsRef.current?.children ?? [], {
			opacity: 1,
			scale: 1,
			y: 0,
			duration: .5,
			stagger: .1,
			ease: "back.out(1.4)"
		}, .8);
		if (heroImgRef.current) gsapWithCSS.to(heroImgRef.current, {
			yPercent: 12,
			ease: "none",
			scrollTrigger: {
				trigger: heroRef.current,
				start: "top top",
				end: "bottom top",
				scrub: 1.5
			}
		});
		return () => {
			tl.kill();
			ScrollTrigger.getAll().forEach((st) => {
				if (st.trigger === heroRef.current || st.trigger === heroImgRef.current) st.kill();
			});
		};
	}, [reducedMotion]);
	(0, import_react.useEffect)(() => {
		if (reducedMotion || !destSectionRef.current || !destGridRef.current) return;
		const heading = destSectionRef.current.querySelector("h2");
		const eyebrow = destSectionRef.current.querySelector(".eyebrow");
		const link = destSectionRef.current.querySelector("a");
		gsapWithCSS.set([
			eyebrow,
			heading,
			link
		], {
			opacity: 0,
			y: 24
		});
		const tl = gsapWithCSS.timeline({ scrollTrigger: {
			trigger: destSectionRef.current,
			start: "top 82%",
			once: true
		} });
		tl.to([
			eyebrow,
			heading,
			link
		], {
			opacity: 1,
			y: 0,
			duration: .7,
			stagger: .12
		});
		const cards = Array.from(destGridRef.current.children);
		gsapWithCSS.set(cards, {
			opacity: 0,
			y: 40
		});
		gsapWithCSS.to(cards, {
			opacity: 1,
			y: 0,
			duration: .75,
			stagger: .08,
			ease: "power3.out",
			scrollTrigger: {
				trigger: destGridRef.current,
				start: "top 85%",
				once: true
			}
		});
		return () => {
			tl.kill();
		};
	}, [reducedMotion]);
	(0, import_react.useEffect)(() => {
		if (reducedMotion || !globeSectionRef.current) return;
		const eyebrow = globeSectionRef.current.querySelector(".float-label");
		const heading = globeSectionRef.current.querySelector("h2");
		const statNum = stat22kRef.current;
		gsapWithCSS.set([
			eyebrow,
			heading,
			statNum
		], {
			opacity: 0,
			y: 24
		});
		const tl = gsapWithCSS.timeline({ scrollTrigger: {
			trigger: globeSectionRef.current,
			start: "top 80%",
			once: true
		} });
		tl.to([eyebrow, heading], {
			opacity: 1,
			y: 0,
			duration: .7,
			stagger: .12
		}).to(statNum, {
			opacity: 1,
			y: 0,
			duration: .6
		}, "-=0.3");
		if (globeImgRef.current) gsapWithCSS.to(globeImgRef.current, {
			yPercent: -8,
			ease: "none",
			scrollTrigger: {
				trigger: globeSectionRef.current,
				start: "top bottom",
				end: "bottom top",
				scrub: 2
			}
		});
		if (globeFloatsRef.current) {
			gsapWithCSS.set(globeFloatsRef.current.children, {
				opacity: 0,
				scale: .85
			});
			gsapWithCSS.to(globeFloatsRef.current.children, {
				opacity: 1,
				scale: 1,
				duration: .5,
				stagger: .15,
				ease: "back.out(1.6)",
				scrollTrigger: {
					trigger: globeImgRef.current,
					start: "top 75%",
					once: true
				}
			});
		}
		if (statsCardsRef.current) {
			gsapWithCSS.set(statsCardsRef.current.children, {
				opacity: 0,
				y: 30
			});
			gsapWithCSS.to(statsCardsRef.current.children, {
				opacity: 1,
				y: 0,
				duration: .65,
				stagger: .12,
				ease: "power3.out",
				scrollTrigger: {
					trigger: statsCardsRef.current,
					start: "top 85%",
					once: true
				}
			});
		}
		return () => {
			tl.kill();
		};
	}, [reducedMotion]);
	(0, import_react.useEffect)(() => {
		if (reducedMotion) return;
		if (stat300Ref.current) animateCountUp(stat300Ref.current, 300, "+", "", 1.4);
		if (stat12kRef.current) animateCountUp(stat12kRef.current, 12e3, "+", "", 1.4);
		if (stat100Ref.current) animateCountUp(stat100Ref.current, 100, "%", "", 1.2);
		if (stat22kRef.current) animateCountUp(stat22kRef.current, 22e3, "+", "", 1.5);
		return () => {
			ScrollTrigger.getAll().forEach((t) => t.kill());
		};
	}, [reducedMotion]);
	(0, import_react.useEffect)(() => {
		if (reducedMotion || !howWorksRef.current || !stepsRef.current) return;
		const heading = howWorksRef.current.querySelector("h2");
		const eyebrow = howWorksRef.current.querySelector(".eyebrow");
		gsapWithCSS.set([eyebrow, heading], {
			opacity: 0,
			y: 24
		});
		const tl = gsapWithCSS.timeline({ scrollTrigger: {
			trigger: howWorksRef.current,
			start: "top 82%",
			once: true
		} });
		tl.to([eyebrow, heading], {
			opacity: 1,
			y: 0,
			duration: .7,
			stagger: .12
		});
		const stepEls = Array.from(stepsRef.current.children);
		gsapWithCSS.set(stepEls, {
			opacity: 0,
			y: 36
		});
		gsapWithCSS.to(stepEls, {
			opacity: 1,
			y: 0,
			duration: .7,
			stagger: .12,
			ease: "power3.out",
			scrollTrigger: {
				trigger: stepsRef.current,
				start: "top 85%",
				once: true
			}
		});
		return () => {
			tl.kill();
		};
	}, [reducedMotion]);
	(0, import_react.useEffect)(() => {
		if (reducedMotion || !featuredSectionRef.current || !featuredGridRef.current) return;
		const heading = featuredSectionRef.current.querySelector("h2");
		const eyebrow = featuredSectionRef.current.querySelector(".eyebrow");
		gsapWithCSS.set([eyebrow, heading], {
			opacity: 0,
			y: 24
		});
		const tl = gsapWithCSS.timeline({ scrollTrigger: {
			trigger: featuredSectionRef.current,
			start: "top 82%",
			once: true
		} });
		tl.to([eyebrow, heading], {
			opacity: 1,
			y: 0,
			duration: .7,
			stagger: .12
		});
		const cards = Array.from(featuredGridRef.current.children);
		gsapWithCSS.set(cards, {
			opacity: 0,
			y: 36
		});
		gsapWithCSS.to(cards, {
			opacity: 1,
			y: 0,
			duration: .7,
			stagger: .1,
			ease: "power3.out",
			scrollTrigger: {
				trigger: featuredGridRef.current,
				start: "top 85%",
				once: true
			}
		});
		return () => {
			tl.kill();
		};
	}, [reducedMotion]);
	(0, import_react.useEffect)(() => {
		if (reducedMotion || !plannerSectionRef.current) return;
		gsapWithCSS.set([plannerTextRef.current, plannerCardRef.current], {
			opacity: 0,
			y: 36
		});
		gsapWithCSS.to([plannerTextRef.current, plannerCardRef.current], {
			opacity: 1,
			y: 0,
			duration: .75,
			stagger: .15,
			ease: "power3.out",
			scrollTrigger: {
				trigger: plannerSectionRef.current,
				start: "top 82%",
				once: true
			}
		});
	}, [reducedMotion]);
	(0, import_react.useEffect)(() => {
		if (reducedMotion || !storiesSectionRef.current) return;
		gsapWithCSS.set([storiesImageRef.current, storiesTextRef.current], { opacity: 0 });
		gsapWithCSS.set(storiesImageRef.current, { x: -32 });
		gsapWithCSS.set(storiesTextRef.current, { x: 32 });
		gsapWithCSS.to([storiesImageRef.current, storiesTextRef.current], {
			opacity: 1,
			x: 0,
			duration: .9,
			stagger: .1,
			ease: "power3.out",
			scrollTrigger: {
				trigger: storiesSectionRef.current,
				start: "top 80%",
				once: true
			}
		});
		const quotes = storiesTextRef.current?.querySelectorAll("blockquote");
		if (quotes?.length) {
			gsapWithCSS.set(quotes, {
				opacity: 0,
				y: 20
			});
			gsapWithCSS.to(quotes, {
				opacity: 1,
				y: 0,
				duration: .6,
				stagger: .15,
				ease: "power3.out",
				scrollTrigger: {
					trigger: storiesTextRef.current,
					start: "top 80%",
					once: true
				}
			});
		}
	}, [reducedMotion]);
	(0, import_react.useEffect)(() => {
		if (reducedMotion || !communitySectionRef.current) return;
		const heading = communitySectionRef.current.querySelector("h2");
		const eyebrow = communitySectionRef.current.querySelector(".eyebrow");
		gsapWithCSS.set([eyebrow, heading], {
			opacity: 0,
			y: 24
		});
		gsapWithCSS.to([eyebrow, heading], {
			opacity: 1,
			y: 0,
			duration: .7,
			stagger: .12,
			scrollTrigger: {
				trigger: communitySectionRef.current,
				start: "top 82%",
				once: true
			}
		});
		if (communityCardsRef.current) {
			const cards = Array.from(communityCardsRef.current.children);
			gsapWithCSS.set(cards, {
				opacity: 0,
				y: 30
			});
			gsapWithCSS.to(cards, {
				opacity: 1,
				y: 0,
				duration: .65,
				stagger: .1,
				ease: "power3.out",
				scrollTrigger: {
					trigger: communityCardsRef.current,
					start: "top 85%",
					once: true
				}
			});
		}
	}, [reducedMotion]);
	(0, import_react.useEffect)(() => {
		if (reducedMotion || !finalCtaRef.current) return;
		const heading = finalCtaRef.current.querySelector("h2");
		const body = finalCtaRef.current.querySelector("p");
		const btns = finalCtaRef.current.querySelector(".flex");
		gsapWithCSS.set([
			heading,
			body,
			btns
		], {
			opacity: 0,
			y: 28
		});
		gsapWithCSS.to([
			heading,
			body,
			btns
		], {
			opacity: 1,
			y: 0,
			duration: .75,
			stagger: .12,
			ease: "power3.out",
			scrollTrigger: {
				trigger: finalCtaRef.current,
				start: "top 82%",
				once: true
			}
		});
	}, [reducedMotion]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				ref: heroRef,
				className: "px-4 pt-28 sm:px-8 sm:pt-36",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-6xl gap-10 lg:grid-cols-[1.05fr_0.95fr] lg:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							ref: eyebrowRef,
							className: "eyebrow",
							children: "Personalized travel planning"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "display-hero mt-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								ref: headlineLine1Ref,
								className: "block",
								children: "Plan the journey."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
								ref: headlineLine2Ref,
								className: "block italic",
								children: "Live the story."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							ref: descRef,
							className: "mt-7 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg",
							children: "Build personalized multi-city trips, discover unforgettable places, manage your budget and share every journey with the people who matter."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							ref: ctaRef,
							className: "mt-9 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								className: "btn-tactile rounded-full px-7",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/signup",
									children: ["Plan Your Trip ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 transition-transform duration-200 group-hover:translate-x-0.5" })]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								variant: "outline",
								className: "btn-tactile rounded-full border-foreground/15 px-7",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/explore/cities",
									children: "Explore Destinations"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
							ref: statsRef,
							className: "mt-12 grid max-w-lg grid-cols-3 gap-6 border-t border-border pt-7",
							children: [
								["12,000+", "Explorers planning"],
								["300+", "Cities & regions"],
								["₹0", "To start planning"]
							].map(([value, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "font-display text-2xl sm:text-3xl",
								children: value
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-xs text-muted-foreground",
								children: label
							})] }, label))
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: heroImageWrapRef,
							className: "relative aspect-[4/5] overflow-hidden rounded-[2.5rem]",
							style: { willChange: "clip-path, opacity" },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								ref: heroImgRef,
								src: images.hero,
								alt: "Coastal road winding along cliffs at golden hour",
								width: 1400,
								height: 1750,
								className: "size-full object-cover",
								style: { willChange: "transform" }
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							ref: floatLabelsRef,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "float-label absolute -left-2 top-10 sm:-left-6",
									style: {
										"--float-dur": "5.2s",
										"--float-delay": "0s"
									},
									children: "12,000+ explorers"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "float-label absolute -right-1 top-1/3 sm:-right-5",
									style: {
										"--float-dur": "6.1s",
										"--float-delay": "0.8s"
									},
									children: "300+ destinations"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "float-label absolute bottom-24 -left-1 sm:-left-8",
									style: {
										"--float-dur": "5.7s",
										"--float-delay": "1.4s"
									},
									children: "Personalized journeys"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "float-label absolute bottom-8 right-4 sm:right-0",
									style: {
										"--float-dur": "6.4s",
										"--float-delay": "0.4s"
									},
									children: "Budget-aware planning"
								})
							]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "px-4 py-24 sm:px-8 sm:py-32",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: destSectionRef,
					className: "mx-auto max-w-6xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-6 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "Destination discovery"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "display-section mt-4 max-w-xl",
							children: "Where will you go next?"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/explore/cities",
							className: "flex items-center gap-2 text-sm font-semibold transition-colors hover:text-primary",
							children: ["Browse all cities ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						ref: destGridRef,
						className: "mt-12 grid gap-4 sm:grid-cols-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DestinationCard, {
								city: featuredCities[0],
								className: "sm:col-span-4",
								ratio: "aspect-[16/11]",
								size: "lg"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DestinationCard, {
								city: featuredCities[1],
								className: "sm:col-span-2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DestinationCard, {
								city: featuredCities[2],
								className: "sm:col-span-2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DestinationCard, {
								city: featuredCities[3],
								className: "sm:col-span-2",
								ratio: "aspect-[4/5]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DestinationCard, {
								city: featuredCities[4],
								className: "sm:col-span-2",
								ratio: "aspect-[4/5]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DestinationCard, {
								city: featuredCities[5],
								className: "sm:col-span-3",
								ratio: "aspect-[16/11]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DestinationCard, {
								city: featuredCities[6],
								className: "sm:col-span-3",
								ratio: "aspect-[16/11]"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				ref: globeSectionRef,
				className: "border-y border-border bg-secondary/50 px-4 py-24 sm:px-8 sm:py-32",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "float-label",
							style: {
								"--float-dur": "5.8s",
								"--float-delay": "0s"
							},
							children: "Real trips, real numbers"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "display-section mx-auto mt-6 max-w-2xl",
							children: "Travelers planning their next adventure"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							ref: stat22kRef,
							className: "display-stat mt-8 text-primary",
							"aria-label": "22,000+ travelers",
							children: "22,000+"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mx-auto mt-10 max-w-3xl",
							style: { overflow: "hidden" },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								ref: globeImgRef,
								src: images.globe,
								alt: "Illustrated globe rising out of clouds",
								loading: "lazy",
								width: 1200,
								height: 912,
								className: "mx-auto w-full",
								style: { willChange: "transform" }
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								ref: globeFloatsRef,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "float-label absolute left-0 top-8 sm:left-4",
										style: {
											"--float-dur": "5.3s",
											"--float-delay": "0.2s",
											"--float-rotate": "-6deg"
										},
										children: "Popular destinations"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "float-label absolute right-0 top-16 sm:right-4",
										style: {
											"--float-dur": "6.2s",
											"--float-delay": "0.7s",
											"--float-rotate": "6deg"
										},
										children: "Trending cities"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "float-label absolute bottom-24 left-2",
										style: {
											"--float-dur": "5.7s",
											"--float-delay": "1.1s",
											"--float-rotate": "-3deg"
										},
										children: "Adventure escapes"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "float-label absolute bottom-16 right-2",
										style: {
											"--float-dur": "6.5s",
											"--float-delay": "0.5s",
											"--float-rotate": "3deg"
										},
										children: "Budget-friendly trips"
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: statsCardsRef,
							className: "mt-4 grid gap-4 text-left sm:grid-cols-3",
							children: [
								{
									ref: stat300Ref,
									stat: "300+",
									title: "Destinations",
									body: "Cities, regions and multi-stop routes ready to plan.",
									target: 300,
									suffix: "+",
									prefix: ""
								},
								{
									ref: stat12kRef,
									stat: "12K+",
									title: "Explorers",
									body: "Travellers building itineraries every month.",
									target: 12e3,
									suffix: "+",
									prefix: ""
								},
								{
									ref: stat100Ref,
									stat: "100%",
									title: "Personalized",
									body: "No fixed packages — every day is yours to shape.",
									target: 100,
									suffix: "%",
									prefix: ""
								}
							].map(({ ref: statRef, stat, title, body }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "panel p-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										ref: statRef,
										className: "font-display text-4xl",
										children: stat
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 font-semibold",
										children: title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted-foreground",
										children: body
									})
								]
							}, title))
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "how-it-works",
				className: "px-4 py-24 sm:px-8 sm:py-32",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: howWorksRef,
					className: "mx-auto max-w-6xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "How GlobeTrotter works"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "display-section mt-4 max-w-2xl",
							children: "Four moves from a vague idea to a day-by-day plan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: stepsRef,
							className: "mt-14 grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-4",
							children: steps.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative border-t border-foreground/20 pt-6 transition-colors duration-300 hover:border-primary/50",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-5xl text-foreground/25",
										children: step.n
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-4 font-display text-2xl",
										children: step.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm leading-relaxed text-muted-foreground",
										children: step.body
									})
								]
							}, step.n))
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "px-4 pb-24 sm:px-8 sm:pb-32",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: featuredSectionRef,
					className: "mx-auto max-w-6xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-6 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "Featured experiences"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "display-section mt-4 max-w-xl",
							children: "Days worth building a trip around"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/explore/activities",
							className: "flex items-center gap-2 text-sm font-semibold transition-colors hover:text-primary",
							children: ["All experiences ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: featuredGridRef,
						className: "mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
						children: [
							"paraglide",
							"aurora",
							"fushimi"
						].map((id) => {
							const activity = activities.find((a) => a.id === id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActivityCard, { activity }, id);
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				ref: plannerSectionRef,
				className: "px-4 pb-24 sm:px-8 sm:pb-32",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-6xl gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						ref: plannerTextRef,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "Inside the planner"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "display-section mt-4",
								children: "Your itinerary, honest about what it costs"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 max-w-lg text-base leading-relaxed text-muted-foreground",
								children: "Add a city, assign nights, and drop activities into any day. GlobeTrotter keeps the timeline, the calendar and the budget in sync so you always know where the money is going."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex flex-wrap gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									className: "btn-tactile rounded-full px-6",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/signup",
										children: "Start planning"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "outline",
									className: "btn-tactile rounded-full px-6",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/share/european-summer-escape",
										children: "See a shared trip"
									})
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						ref: plannerCardRef,
						className: "panel p-5 sm:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "eyebrow",
										children: "Sample itinerary"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "truncate font-display text-2xl",
										children: sampleTrip.name
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "float-label shrink-0",
									style: {
										"--float-dur": "5.5s",
										"--float-delay": "0.3s"
									},
									children: "8 days · 3 cities"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-6 space-y-3",
								children: [
									[
										"Day 01",
										"Paris",
										"Montmartre food walk",
										"09:30",
										3400
									],
									[
										"Day 02",
										"Paris",
										"Eiffel Tower summit",
										"10:00",
										2800
									],
									[
										"Day 04",
										"Zurich",
										"Lake Zurich boat loop",
										"15:30",
										1900
									],
									[
										"Day 06",
										"Interlaken",
										"Paragliding flight",
										"11:00",
										12500
									]
								].map(([day, city, name, time, cost]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-3 rounded-2xl bg-secondary/70 p-3.5 transition-colors duration-200 hover:bg-secondary",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-14 shrink-0 text-xs font-semibold text-muted-foreground",
											children: day
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-12 shrink-0 font-display",
											children: time
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "min-w-0 flex-1 truncate text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold",
												children: name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-muted-foreground",
												children: [" · ", city]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "shrink-0 text-sm font-semibold",
											children: inr(Number(cost))
										})
									]
								}, String(day) + String(name)))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 flex items-center justify-between border-t border-border pt-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted-foreground",
									children: "Estimated trip total"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-2xl",
									children: "₹1,52,700"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				ref: storiesSectionRef,
				className: "border-y border-border bg-secondary/50 px-4 py-24 sm:px-8 sm:py-32",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-6xl gap-10 lg:grid-cols-[1fr_1fr] lg:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: storiesImageRef,
						className: "image-zoom overflow-hidden rounded-[2.5rem]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: images.story,
							alt: "Traveller looking out over a misty valley",
							loading: "lazy",
							width: 1200,
							height: 900,
							className: "aspect-[4/3] w-full object-cover"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						ref: storiesTextRef,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "Travel stories"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "display-section mt-4",
								children: "Plans that turned into good stories"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-8 space-y-6",
								children: [["We planned eight days across France and Switzerland in one evening. The budget page stopped two arguments before they started.", "Aarav Mehta · European Summer Escape"], ["I copied a shared Japan itinerary, swapped two days for Kyoto gardens and it was ready.", "Nikita Rao · Japan Discovery"]].map(([quote, who]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
									className: "panel p-6 transition-shadow duration-300 hover:shadow-lift",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quote, { className: "size-5 text-primary" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-base leading-relaxed",
											children: quote
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
											className: "mt-4 text-xs uppercase tracking-[0.12em] text-muted-foreground",
											children: who
										})
									]
								}, who))
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				ref: communitySectionRef,
				className: "px-4 py-24 sm:px-8 sm:py-32",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-6xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-8 lg:grid-cols-[1fr_1fr] lg:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "Community"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "display-section mt-4",
								children: "Borrow a route. Make it your own."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 max-w-lg text-base leading-relaxed text-muted-foreground",
								children: "Every public itinerary can be copied in one click — dates, cities and activities included. Edit what you like, keep what works."
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: communityCardsRef,
							className: "grid gap-4 sm:grid-cols-2",
							children: seedTrips().filter((t) => t.isPublic).map((trip) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/share/$tripId",
								params: { tripId: trip.id },
								className: "panel image-zoom card-lift overflow-hidden",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: trip.coverImage,
									alt: trip.name,
									loading: "lazy",
									className: "aspect-[16/10] w-full object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-xl",
										children: trip.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-sm text-muted-foreground",
										children: [trip.stops.length, " cities · shared by Aarav"]
									})]
								})]
							}, trip.id))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "panel mt-20 overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							ref: finalCtaRef,
							className: "grid gap-8 p-8 sm:p-14 lg:grid-cols-[1.2fr_0.8fr] lg:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "display-section",
								children: "Your world. Your route. Your story."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 max-w-lg text-base leading-relaxed text-muted-foreground",
								children: "Create a free account and turn a shortlist of places into a plan you can actually follow."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-3 lg:justify-end",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "lg",
									className: "btn-tactile rounded-full px-7",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/signup",
										children: "Create your account"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "lg",
									variant: "outline",
									className: "btn-tactile rounded-full px-7",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/login",
										children: "Login"
									})
								})]
							})]
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { Landing as component };
