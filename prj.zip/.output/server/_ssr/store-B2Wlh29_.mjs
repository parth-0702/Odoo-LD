import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { n as format, r as addDays, t as parseISO } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-B2Wlh29_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var paris_default = "/assets/paris-C_GZoEBv.jpg";
var zurich_default = "/assets/zurich-BqxEdLBG.jpg";
var interlaken_default = "/assets/interlaken-XGf7Ep15.jpg";
var tokyo_default = "/assets/tokyo-BYTzBaOy.jpg";
var kyoto_default = "/assets/kyoto-DAIwZ2xJ.jpg";
var iceland_default = "/assets/iceland-DmzUCyvf.jpg";
var bali_default = "/assets/bali-70OxdhPD.jpg";
var alps_default = "/assets/alps-BxUGqFM0.jpg";
var dubai_default = "/assets/dubai-Bab0gJAh.jpg";
var patagonia_default = "/assets/patagonia-PxxxIHNt.jpg";
var himalaya_default = "/assets/himalaya-oU-6zQQS.jpg";
var images = {
	hero: "/assets/hero-lcWRsf_Q.jpg",
	globe: "/assets/globe-Beh0RjRp.jpg",
	story: "/assets/story--44YF01H.jpg",
	paris: paris_default,
	zurich: zurich_default,
	interlaken: interlaken_default,
	tokyo: tokyo_default,
	kyoto: kyoto_default,
	iceland: iceland_default,
	bali: bali_default,
	alps: alps_default,
	dubai: dubai_default,
	patagonia: patagonia_default,
	himalaya: himalaya_default
};
var cities = [
	{
		id: "paris",
		name: "Paris",
		country: "France",
		region: "Western Europe",
		costIndex: "High",
		popularity: 98,
		avgDailyCost: 9200,
		image: paris_default,
		description: "Boulevards, riverside bookstalls and long dinners — a city built for slow, deliberate wandering."
	},
	{
		id: "zurich",
		name: "Zurich",
		country: "Switzerland",
		region: "Central Europe",
		costIndex: "High",
		popularity: 84,
		avgDailyCost: 11500,
		image: zurich_default,
		description: "Lake swims before work, old-town lanes after — a calm, precise base for alpine detours."
	},
	{
		id: "interlaken",
		name: "Interlaken",
		country: "Switzerland",
		region: "Central Europe",
		costIndex: "Medium",
		popularity: 88,
		avgDailyCost: 8600,
		image: interlaken_default,
		description: "Two lakes, one valley and a cable car for every mood. The Alps at their most theatrical."
	},
	{
		id: "tokyo",
		name: "Tokyo",
		country: "Japan",
		region: "East Asia",
		costIndex: "High",
		popularity: 96,
		avgDailyCost: 8800,
		image: tokyo_default,
		description: "Thirteen cities stitched into one. Neon crossings, quiet shrines and the world's best trains."
	},
	{
		id: "kyoto",
		name: "Kyoto",
		country: "Japan",
		region: "East Asia",
		costIndex: "Medium",
		popularity: 92,
		avgDailyCost: 7200,
		image: kyoto_default,
		description: "Temple gardens, bamboo groves and tea houses that have not changed their minds in centuries."
	},
	{
		id: "reykjavik",
		name: "Reykjavík",
		country: "Iceland",
		region: "Nordics",
		costIndex: "High",
		popularity: 81,
		avgDailyCost: 10400,
		image: iceland_default,
		description: "A small capital with an enormous backyard: black beaches, geysers and winter aurora."
	},
	{
		id: "bali",
		name: "Bali",
		country: "Indonesia",
		region: "Southeast Asia",
		costIndex: "Low",
		popularity: 94,
		avgDailyCost: 3900,
		image: bali_default,
		description: "Rice terraces at sunrise, surf in the afternoon, and villages that reward staying longer."
	},
	{
		id: "swiss-alps",
		name: "Swiss Alps",
		country: "Switzerland",
		region: "Central Europe",
		costIndex: "High",
		popularity: 90,
		avgDailyCost: 9800,
		image: alps_default,
		description: "Chalet villages under glaciers, with trails that turn a walk into an entire day's story."
	},
	{
		id: "dubai",
		name: "Dubai",
		country: "UAE",
		region: "Middle East",
		costIndex: "Medium",
		popularity: 87,
		avgDailyCost: 7600,
		image: dubai_default,
		description: "Dunes on one side, glass towers on the other — a stopover that easily becomes a stay."
	},
	{
		id: "patagonia",
		name: "Patagonia",
		country: "Argentina",
		region: "South America",
		costIndex: "Medium",
		popularity: 76,
		avgDailyCost: 6400,
		image: patagonia_default,
		description: "Granite spires, glacial lakes and wind that makes every photograph feel earned."
	},
	{
		id: "manali",
		name: "Manali",
		country: "India",
		region: "South Asia",
		costIndex: "Low",
		popularity: 79,
		avgDailyCost: 2800,
		image: himalaya_default,
		description: "Deodar forests, river cafés and the gateway to high Himalayan passes."
	}
];
var activities = [
	{
		id: "eiffel",
		name: "Eiffel Tower Summit",
		cityId: "paris",
		category: "Sightseeing",
		durationMins: 150,
		cost: 2800,
		image: paris_default,
		description: "Timed-entry lift to the summit, best booked for the last slot before sunset."
	},
	{
		id: "seine",
		name: "Seine River Cruise",
		cityId: "paris",
		category: "Sightseeing",
		durationMins: 90,
		cost: 1600,
		image: paris_default,
		description: "An hour on the water past Île de la Cité, Orsay and the Louvre facades."
	},
	{
		id: "montmartre-food",
		name: "Montmartre Food Walk",
		cityId: "paris",
		category: "Food",
		durationMins: 180,
		cost: 3400,
		image: paris_default,
		description: "Cheese, baguette and bistro stops through the hill's back lanes."
	},
	{
		id: "louvre",
		name: "Louvre Highlights",
		cityId: "paris",
		category: "Culture",
		durationMins: 210,
		cost: 2200,
		image: paris_default,
		description: "A curated three-hour route through the Denon and Sully wings."
	},
	{
		id: "lake-zurich",
		name: "Lake Zurich Boat Loop",
		cityId: "zurich",
		category: "Nature",
		durationMins: 120,
		cost: 1900,
		image: zurich_default,
		description: "Slow ferry along the gold coast with mountain views on clear days."
	},
	{
		id: "old-town-zurich",
		name: "Old Town Walking Tour",
		cityId: "zurich",
		category: "Culture",
		durationMins: 100,
		cost: 1200,
		image: zurich_default,
		description: "Guildhouses, Grossmünster and the Lindenhof terrace."
	},
	{
		id: "alps-hike",
		name: "Swiss Alps Day Hike",
		cityId: "interlaken",
		category: "Adventure",
		durationMins: 330,
		cost: 3600,
		image: alps_default,
		description: "Ridge trail with a mountain-hut lunch and cable car descent."
	},
	{
		id: "paraglide",
		name: "Paragliding Over Interlaken",
		cityId: "interlaken",
		category: "Adventure",
		durationMins: 120,
		cost: 12500,
		image: interlaken_default,
		description: "Tandem flight from Beatenberg landing beside the Höhematte."
	},
	{
		id: "jungfrau",
		name: "Jungfraujoch Rail Journey",
		cityId: "interlaken",
		category: "Sightseeing",
		durationMins: 420,
		cost: 9800,
		image: alps_default,
		description: "Cogwheel train to Europe's highest station and the glacier plateau."
	},
	{
		id: "shibuya",
		name: "Shibuya & Harajuku Evening",
		cityId: "tokyo",
		category: "Nightlife",
		durationMins: 180,
		cost: 2400,
		image: tokyo_default,
		description: "Crossing, backstreet listening bars and a late izakaya."
	},
	{
		id: "tsukiji",
		name: "Toyosu Market Breakfast",
		cityId: "tokyo",
		category: "Food",
		durationMins: 120,
		cost: 2600,
		image: tokyo_default,
		description: "Early sushi counter breakfast and knife shopping afterwards."
	},
	{
		id: "teamlab",
		name: "Digital Art Museum",
		cityId: "tokyo",
		category: "Culture",
		durationMins: 150,
		cost: 3100,
		image: tokyo_default,
		description: "Room-scale light installations — book the first entry slot."
	},
	{
		id: "fushimi",
		name: "Fushimi Inari Shrine",
		cityId: "kyoto",
		category: "Culture",
		durationMins: 150,
		cost: 0,
		image: kyoto_default,
		description: "Ten thousand vermilion gates up the mountain; go before 7am."
	},
	{
		id: "arashiyama",
		name: "Arashiyama Bamboo Grove",
		cityId: "kyoto",
		category: "Nature",
		durationMins: 120,
		cost: 600,
		image: kyoto_default,
		description: "Grove walk plus the riverside temple garden at Tenryū-ji."
	},
	{
		id: "tea-ceremony",
		name: "Machiya Tea Ceremony",
		cityId: "kyoto",
		category: "Wellness",
		durationMins: 90,
		cost: 2900,
		image: kyoto_default,
		description: "Hosted matcha ceremony in a restored townhouse."
	},
	{
		id: "aurora",
		name: "Northern Lights Tour",
		cityId: "reykjavik",
		category: "Nature",
		durationMins: 240,
		cost: 7400,
		image: iceland_default,
		description: "Small-group chase away from city light, with a second-night guarantee."
	},
	{
		id: "golden-circle",
		name: "Golden Circle Drive",
		cityId: "reykjavik",
		category: "Sightseeing",
		durationMins: 480,
		cost: 8900,
		image: iceland_default,
		description: "Þingvellir, Geysir and Gullfoss in one long, bright day."
	},
	{
		id: "ubud-terrace",
		name: "Tegallalang Sunrise Walk",
		cityId: "bali",
		category: "Nature",
		durationMins: 150,
		cost: 1400,
		image: bali_default,
		description: "Terrace paths before the crowds, ending at a valley coffee bar."
	},
	{
		id: "surf-lesson",
		name: "Canggu Surf Lesson",
		cityId: "bali",
		category: "Adventure",
		durationMins: 120,
		cost: 2200,
		image: bali_default,
		description: "Beginner-friendly beach break with board and instructor."
	},
	{
		id: "desert-safari",
		name: "Evening Desert Safari",
		cityId: "dubai",
		category: "Adventure",
		durationMins: 300,
		cost: 5600,
		image: dubai_default,
		description: "Dune drive, camp dinner and stargazing on the return."
	},
	{
		id: "souk",
		name: "Gold & Spice Souk",
		cityId: "dubai",
		category: "Shopping",
		durationMins: 120,
		cost: 900,
		image: dubai_default,
		description: "Creek crossing by abra and a walk through the old trading lanes."
	},
	{
		id: "torres",
		name: "Torres del Paine Base Trek",
		cityId: "patagonia",
		category: "Adventure",
		durationMins: 540,
		cost: 6800,
		image: patagonia_default,
		description: "Full-day trek to the base of the towers with a packed lunch."
	},
	{
		id: "solang",
		name: "Solang Valley Day",
		cityId: "manali",
		category: "Adventure",
		durationMins: 300,
		cost: 2400,
		image: himalaya_default,
		description: "Ropeway, alpine meadow walk and river-side maggi stop."
	},
	{
		id: "hadimba",
		name: "Hadimba Temple & Old Manali",
		cityId: "manali",
		category: "Culture",
		durationMins: 150,
		cost: 700,
		image: himalaya_default,
		description: "Cedar-forest temple followed by cafés along the Manalsu."
	},
	{
		id: "rohtang",
		name: "Atal Tunnel & Sissu",
		cityId: "manali",
		category: "Sightseeing",
		durationMins: 420,
		cost: 4200,
		image: himalaya_default,
		description: "Cross into Lahaul for glacier views and the Sissu waterfall."
	}
];
var activityById = (id) => activities.find((a) => a.id === id);
var cityById = (id) => cities.find((c) => c.id === id);
var demoUser = {
	id: "u_aarav",
	name: "Aarav Mehta",
	email: "aarav@globetrotter.app",
	language: "English (India)",
	travelStyle: [
		"Slow travel",
		"Mountains",
		"Food-led"
	],
	role: "admin"
};
var seq = 0;
var uid = (prefix) => `${prefix}_${Date.now().toString(36)}${(seq++).toString(36)}`;
var buildDays = (start, nights) => Array.from({ length: nights }, (_, i) => ({
	id: uid("day"),
	date: format(addDays(parseISO(start), i), "yyyy-MM-dd"),
	activities: []
}));
var stop = (cityId, start, nights, plan) => {
	const days = buildDays(start, nights).map((day, i) => ({
		...day,
		activities: (plan[i] ?? []).map(([activityId, time]) => ({
			id: uid("ia"),
			activityId,
			time,
			cost: activityById(activityId)?.cost ?? 0
		}))
	}));
	return {
		id: uid("stop"),
		cityId,
		startDate: start,
		endDate: format(addDays(parseISO(start), nights - 1), "yyyy-MM-dd"),
		days
	};
};
var seedTrips = () => [
	{
		id: "european-summer-escape",
		userId: demoUser.id,
		name: "European Summer Escape",
		description: "Two weeks exploring France and Switzerland at a walkable pace.",
		startDate: "2026-09-12",
		endDate: "2026-09-19",
		coverImage: paris_default,
		plannedBudget: 145e3,
		isPublic: true,
		createdAt: "2026-08-02",
		expenses: {
			transport: 42e3,
			accommodation: 56e3,
			meals: 21e3,
			other: 8e3
		},
		stops: [
			stop("paris", "2026-09-12", 3, [
				[
					["montmartre-food", "09:30"],
					["louvre", "13:00"],
					["seine", "18:30"]
				],
				[["eiffel", "10:00"], ["seine", "19:00"]],
				[["louvre", "11:00"]]
			]),
			stop("zurich", "2026-09-15", 2, [[["old-town-zurich", "10:00"], ["lake-zurich", "15:30"]], [["lake-zurich", "09:30"]]]),
			stop("interlaken", "2026-09-17", 3, [
				[["alps-hike", "08:00"]],
				[["paraglide", "11:00"], ["jungfrau", "07:30"]],
				[["jungfrau", "07:00"]]
			])
		]
	},
	{
		id: "himalayan-adventure",
		userId: demoUser.id,
		name: "Himalayan Adventure",
		description: "A week of high passes, cedar forests and river cafés in Himachal.",
		startDate: "2026-10-04",
		endDate: "2026-10-07",
		coverImage: himalaya_default,
		plannedBudget: 38e3,
		isPublic: false,
		createdAt: "2026-08-10",
		expenses: {
			transport: 12e3,
			accommodation: 14e3,
			meals: 6e3,
			other: 2500
		},
		stops: [stop("manali", "2026-10-04", 4, [
			[["hadimba", "10:00"]],
			[["solang", "08:30"]],
			[["rohtang", "06:30"]],
			[["hadimba", "16:00"]]
		])]
	},
	{
		id: "japan-discovery",
		userId: demoUser.id,
		name: "Japan Discovery",
		description: "Tokyo's energy first, then Kyoto's gardens to slow the trip down.",
		startDate: "2026-04-06",
		endDate: "2026-04-11",
		coverImage: tokyo_default,
		plannedBudget: 12e4,
		isPublic: true,
		createdAt: "2026-02-14",
		expenses: {
			transport: 38e3,
			accommodation: 41e3,
			meals: 18e3,
			other: 6e3
		},
		stops: [stop("tokyo", "2026-04-06", 3, [
			[["tsukiji", "07:00"], ["shibuya", "18:00"]],
			[["teamlab", "10:00"]],
			[["shibuya", "19:00"]]
		]), stop("kyoto", "2026-04-09", 3, [
			[["fushimi", "06:30"]],
			[["arashiyama", "08:00"], ["tea-ceremony", "15:00"]],
			[["tea-ceremony", "11:00"]]
		])]
	}
];
var savedSeed = [
	"reykjavik",
	"bali",
	"patagonia"
];
var KEY = "globetrotter:state:v1";
var StoreContext = (0, import_react.createContext)(null);
var initial = () => ({
	user: null,
	trips: seedTrips(),
	saved: savedSeed
});
var resequence = (trip) => {
	let cursor = parseISO(trip.startDate);
	const stops = trip.stops.map((stop) => {
		const nights = Math.max(1, stop.days.length);
		const start = format(cursor, "yyyy-MM-dd");
		const days = stop.days.map((day, i) => ({
			...day,
			date: format(addDays(cursor, i), "yyyy-MM-dd")
		}));
		cursor = addDays(cursor, nights);
		return {
			...stop,
			startDate: start,
			endDate: format(addDays(parseISO(start), nights - 1), "yyyy-MM-dd"),
			days
		};
	});
	const lastDay = stops.at(-1)?.endDate;
	return {
		...trip,
		stops,
		endDate: lastDay && lastDay > trip.endDate ? lastDay : trip.endDate
	};
};
function StoreProvider({ children }) {
	const [state, setState] = (0, import_react.useState)(initial);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(KEY);
			if (raw) setState({
				...initial(),
				...JSON.parse(raw)
			});
		} catch {}
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		try {
			localStorage.setItem(KEY, JSON.stringify(state));
		} catch {}
	}, [state, hydrated]);
	const patchTrip = (0, import_react.useCallback)((id, fn) => {
		setState((prev) => ({
			...prev,
			trips: prev.trips.map((t) => t.id === id ? resequence(fn(t)) : t)
		}));
	}, []);
	const value = (0, import_react.useMemo)(() => {
		return {
			...state,
			hydrated,
			isAuthed: Boolean(state.user),
			login: (email) => setState((prev) => ({
				...prev,
				user: {
					...demoUser,
					email
				}
			})),
			signup: (name, email) => setState((prev) => ({
				...prev,
				user: {
					...demoUser,
					id: uid("u"),
					name,
					email,
					role: "admin"
				}
			})),
			logout: () => setState((prev) => ({
				...prev,
				user: null
			})),
			updateUser: (patch) => setState((prev) => ({
				...prev,
				user: prev.user ? {
					...prev.user,
					...patch
				} : prev.user
			})),
			tripById: (id) => state.trips.find((t) => t.id === id),
			createTrip: (input) => {
				const trip = {
					id: uid("trip"),
					userId: state.user?.id ?? demoUser.id,
					name: input.name,
					description: input.description,
					startDate: input.startDate,
					endDate: input.endDate,
					coverImage: input.coverImage,
					plannedBudget: input.plannedBudget,
					isPublic: false,
					stops: [],
					expenses: {
						transport: 0,
						accommodation: 0,
						meals: 0,
						other: 0
					},
					createdAt: format(/* @__PURE__ */ new Date(), "yyyy-MM-dd")
				};
				setState((prev) => ({
					...prev,
					trips: [trip, ...prev.trips]
				}));
				return trip;
			},
			updateTrip: (id, patch) => patchTrip(id, (trip) => ({
				...trip,
				...patch
			})),
			deleteTrip: (id) => setState((prev) => ({
				...prev,
				trips: prev.trips.filter((t) => t.id !== id)
			})),
			copyTrip: (id) => {
				const source = state.trips.find((t) => t.id === id);
				if (!source) return void 0;
				const copy = {
					...structuredClone(source),
					id: uid("trip"),
					name: `${source.name} (copy)`,
					isPublic: false,
					userId: state.user?.id ?? demoUser.id,
					createdAt: format(/* @__PURE__ */ new Date(), "yyyy-MM-dd")
				};
				setState((prev) => ({
					...prev,
					trips: [copy, ...prev.trips]
				}));
				return copy;
			},
			addStop: (tripId, cityId, nights) => patchTrip(tripId, (trip) => {
				const lastEnd = trip.stops.at(-1)?.endDate;
				const start = lastEnd ? format(addDays(parseISO(lastEnd), 1), "yyyy-MM-dd") : trip.startDate;
				const newStop = {
					id: uid("stop"),
					cityId,
					startDate: start,
					endDate: format(addDays(parseISO(start), nights - 1), "yyyy-MM-dd"),
					days: buildDays(start, nights)
				};
				return {
					...trip,
					stops: [...trip.stops, newStop]
				};
			}),
			removeStop: (tripId, stopId) => patchTrip(tripId, (trip) => ({
				...trip,
				stops: trip.stops.filter((s) => s.id !== stopId)
			})),
			moveStop: (tripId, stopId, direction) => patchTrip(tripId, (trip) => {
				const idx = trip.stops.findIndex((s) => s.id === stopId);
				const target = idx + direction;
				if (idx < 0 || target < 0 || target >= trip.stops.length) return trip;
				const stops = [...trip.stops];
				const [moved] = stops.splice(idx, 1);
				if (moved) stops.splice(target, 0, moved);
				return {
					...trip,
					stops
				};
			}),
			addActivity: (tripId, dayId, activityId, time) => patchTrip(tripId, (trip) => ({
				...trip,
				stops: trip.stops.map((stop) => ({
					...stop,
					days: stop.days.map((day) => day.id === dayId ? {
						...day,
						activities: [...day.activities, {
							id: uid("ia"),
							activityId,
							time: time ?? nextSlot(day.activities.length),
							cost: activityById(activityId)?.cost ?? 0
						}].sort((a, b) => a.time.localeCompare(b.time))
					} : day)
				}))
			})),
			removeActivity: (tripId, dayId, itemId) => patchTrip(tripId, (trip) => ({
				...trip,
				stops: trip.stops.map((stop) => ({
					...stop,
					days: stop.days.map((day) => day.id === dayId ? {
						...day,
						activities: day.activities.filter((a) => a.id !== itemId)
					} : day)
				}))
			})),
			moveActivity: (tripId, dayId, itemId, direction) => patchTrip(tripId, (trip) => ({
				...trip,
				stops: trip.stops.map((stop) => ({
					...stop,
					days: stop.days.map((day) => {
						if (day.id !== dayId) return day;
						const idx = day.activities.findIndex((a) => a.id === itemId);
						const target = idx + direction;
						if (idx < 0 || target < 0 || target >= day.activities.length) return day;
						const activities = [...day.activities];
						const [moved] = activities.splice(idx, 1);
						if (moved) activities.splice(target, 0, moved);
						return {
							...day,
							activities
						};
					})
				}))
			})),
			toggleSaved: (cityId) => setState((prev) => ({
				...prev,
				saved: prev.saved.includes(cityId) ? prev.saved.filter((c) => c !== cityId) : [...prev.saved, cityId]
			})),
			isSaved: (cityId) => state.saved.includes(cityId)
		};
	}, [
		state,
		patchTrip,
		hydrated
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreContext.Provider, {
		value,
		children
	});
}
var nextSlot = (count) => {
	const hour = Math.min(21, 9 + count * 3);
	return `${String(hour).padStart(2, "0")}:00`;
};
function useStore() {
	const ctx = (0, import_react.useContext)(StoreContext);
	if (!ctx) throw new Error("useStore must be used inside StoreProvider");
	return ctx;
}
//#endregion
export { demoUser as a, useStore as c, cityById as i, activities as n, images as o, cities as r, seedTrips as s, StoreProvider as t };
